<?php get_header();?>
		<!--Container-->
		<section id="container">
			<div class="wrap-container">
				<div class="zerogrid">
					<div class="row">
						<div class="col-1-2">
							<a href="<?php echo site_url();?>"><img src="<?php echo get_template_directory_uri();?>/images/logo.png"></a>
						</div>
						<div class="col-1-2">
							<form id="form-container" action="" class="f-right">
								<!--<input type="submit" id="searchsubmit" value="" />-->
								<a class="search-submit-button" href="javascript:void(0)">
									<i class="fa fa-search"></i>
								</a>
								<div id="searchtext">
									<input type="text" id="s" name="s" placeholder="Search Something...">
								</div>
							</form>
						</div>
					</div>
					<div class="crumbs">
						<ul>
							<li><a href="index.html">Home</a></li>
							<li><a href="gallery.html">Blog</a></li>
						</ul>
					</div>
					<div id="main-content" class="col-12-3">
						<div class="wrap-content">
							<?php 
						
								if (have_posts() ){
									while (have_posts() ){
										the_post();?>
											<article>
												<div class="art-header">
													<a href="<?php the_permalink();?>"><h3><?php the_title();?></h3></a>
													<div class="info">Posted on <?php the_date();?> By: <?php the_author(); ?> <a href="<?php the_permalink();?>"><?php comments_number('No comment','1 comment','% comment');?></a></div>
												</div>
												<div class="art-content">
													<?php the_post_thumbnail(); ?>
													<p><?php the_content();?></p>
												</div>
												
											</article>
										<?php }
								}else{
									echo 'No Post';
								}
							?>
							
						</div>
						<?php comments_template();?>
					</div>
				</div>
			</div>
		</section>
<?php get_footer();?>		
<?php wp_footer();?>	
</body>
</html>