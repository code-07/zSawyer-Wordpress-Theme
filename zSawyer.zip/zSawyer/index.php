<?php get_header();?>
		<!--Container-->
		<section id="container">
			<div class="wrap-container">
				<div class="zerogrid">
					<div class="row">
						<div class="col-1-2">
							<a href="<?php echo site_url();?>"><img src="<?php global  $zsawyer_master; echo  $zsawyer_master['site_logo']['url']; ?>"></a>
						</div>
						<div class="col-1-2">
							<form id="form-container" action="" class="f-right">
								<!--<input type="submit" id="searchsubmit" value="" />-->
								<a class="search-submit-button" href="javascript:void(0)">
									<i class="fa fa-search"></i>
								</a>
								<div id="searchtext">
									<input type="text" id="s" name="s" placeholder="Search Something...">
								</div>
							</form>
						</div>
					</div>
					<div class="crumbs">
						<ul>
							<li><a href="index.html">Home</a></li>
							<li><a href="gallery.html">Blog</a></li>
						</ul>
					</div>
					<div id="main-content" class="col-2-3">
						<div class="wrap-content">
							<?php 
						
								if (have_posts() ){
									while (have_posts() ){
										the_post();?>
											<article>
												<div class="art-header">
													<a href="<?php the_permalink();?>"><h3><?php the_title();?></h3></a>
													<div class="info">Posted on <?php the_date();?> By: <?php the_author(); ?> <a href="<?php the_permalink();?>"><?php comments_number();?></a></div>
												</div>
												<div class="art-content">
													<?php the_post_thumbnail(); ?>
													<p><?php echo wp_trim_words(get_the_content(),50,'....');?></p>
												</div>
												<a class="button" href="<?php the_permalink();?>">Learn More</a>
												<div class="line"></div>
											</article>
										<?php }
								}else{
									echo 'No Post';
								}
							?>
							<?php 
								the_posts_pagination(array(
									'next_text'=>'Next',
									'prev_text'=>'Prev',
									'screen_reader_text'=>' '

								));
							?>
						</div>
					</div>
					<?php get_sidebar();?>
				</div>
			</div>
		</section>
<?php get_footer();?>		
<?php wp_footer();?>	
</body>
</html>
