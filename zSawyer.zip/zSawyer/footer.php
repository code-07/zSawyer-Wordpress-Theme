<!--Footer-->
<?php global  $zsawyer_master;?>
		<footer>
			<div class="wrap-footer">
				<div class="zerogrid">
					<div class="row">
						<div class="col-1-3">
							<div class="wrap-col">
								<?php global  $zsawyer_master; echo  $zsawyer_master['copy_text']; ?>
							</div>
						</div>
						<div class="col-1-3">
							<div class="wrap-col">
								<ul class="social-buttons">
								<?php 
								if(is_array($zsawyer_master['icon_slide'])){
								foreach(  $zsawyer_master['icon_slide'] as $single){
									?>
									<li><a href="<?php echo $single['url']; ?>"><i class="fa <?php echo $single['title']; ?>"></i></a>
									</li>
								 <?php }
								}
								?>
									
								</ul>
							</div>
						</div>
						<div class="col-1-3">
							<div class="wrap-col">
								<ul class="quick-link">
									<?php global  $zsawyer_master; echo  $zsawyer_master['policy_text']; ?>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>