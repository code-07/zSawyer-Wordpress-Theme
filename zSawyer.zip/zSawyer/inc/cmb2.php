<?php
/**
 * Get the bootstrap!
 */
if ( file_exists( __DIR__ . '/cmb2/init.php' ) ) {
  require_once __DIR__ . '/cmb2/init.php';
} elseif ( file_exists(  __DIR__ . '/CMB2/init.php' ) ) {
  require_once __DIR__ . '/CMB2/init.php';
}

add_action( 'cmb2_admin_init', 'zsawyer_cmb2' );

function zsawyer_cmb2(){
	$pref='_zsawyer_';
    $service_item = new_cmb2_box( array(
        'id'            => 'service_metabox',
        'title'         => __( 'Service Metabox', 'zsawyer' ),
        'object_types'  => array( 'services', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );	

    $service_item->add_field( array(
        'name'       => __( 'Service Description', 'zsawyer' ),
        'desc'       => __( 'Write Here Service Description ', 'cmb2' ),
        'id'         => $pref.'service_description',
        'type'       => 'textarea',
       
    ) );
}
