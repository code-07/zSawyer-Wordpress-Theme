<?php
get_template_directory_uri();
function zkimnet_theme(){
	add_theme_support('title-tag');
	register_nav_menus(array(
			'main-menu'=>'Main Menu'
		));
	add_theme_support('post-thumbnails');
	add_image_size('post-thumb',940, 300, true);
	add_theme_support('html5');

	

}
add_action('after_setup_theme','zkimnet_theme');

function zkimnet_scripts_style() {
	wp_enqueue_style('zerogrid', get_template_directory_uri().'/css/zerogrid.css');
	wp_enqueue_style('zkimnet_style', get_template_directory_uri().'/css/style.css');
	wp_enqueue_style('menu_style', get_template_directory_uri().'/css/menu.css');
	wp_enqueue_style('lightbox_style', get_template_directory_uri().'/css/lightbox.css');		
	wp_enqueue_style('carousel_style', get_template_directory_uri().'/css/owl.carousel.css');
	wp_enqueue_style('fontawesome_style', get_template_directory_uri().'/font-awesome/css/font-awesome.min.css');
	wp_enqueue_style('style', get_stylesheet_uri());


	wp_enqueue_script('jquery',null,'v4.4.7',true);
	wp_enqueue_script('script', get_template_directory_uri().'/js/script.js',null,'v4.4.7',true);	
	wp_enqueue_script('lightbox', get_template_directory_uri().'/js/lightbox-plus-jquery.min.js',null,'v4.4.7',true);
	wp_enqueue_script('owlcarousel', get_template_directory_uri().'/owl-carousel/owl.carousel.js',null,'v4.4.7',true);
	wp_enqueue_script('custom', get_template_directory_uri().'/custom.js',null,'v4.4.7',true);
}
add_action('wp_enqueue_scripts','zkimnet_scripts_style');

function zkimnet_custom_post() {
	register_post_type('slider',array(
			'labels'=>array(
				'name'=>'Main Slider',
				'menu_name'=>'Slider Menu',
				'all_items'=>'All Slider',
				'add_new'=>'Add New Slide',
				'add_new_item'=>'Add New Slide Item'
			),
			'public'=>true,
			'supports'=>array(
				'thumbnail','page-attributes'
			),
		));
	register_post_type('image',array(
			'labels'=>array(
				'name'=>'Home Image',
				'menu_name'=>'Image Menu',
				'all_items'=>'All Image',
				'add_new'=>'Add New Image',
				'add_new_item'=>'Add New Slide Image'
			),
			'public'=>true,
			'supports'=>array(
				'title','thumbnail','page-attributes'
			),
		));
	register_post_type('services',array(
			'labels'=>array(
				'name'=>'Home service',
				'menu_name'=>'Service Menu',
				'all_items'=>'All services',
				'add_new'=>'Add New service',
				'add_new_item'=>'Add New Service Item'
			),
			'public'=>true,
			'supports'=>array(
				'title','thumbnail','custom-fields','page-attributes'
			),
		));

}
add_action('init','zkimnet_custom_post');
function our_widgets(){
	register_sidebar(array(
		'name' 				=> 'Latest Albums',
		'description'     	=> 'Add your album',
		'id'				=> 'latest-album',
		'before_widget'		=> '<div class="box">',
		'before_title'		=> '<div class="heading"><h2>',
		'after_title'		=> '</h2></div><div class="content">',
		'after_widget'		=> '</div></div>'
	));
}
add_action('widgets_init','our_widgets');

include_once('inc/cmb2.php');
include_once('inc/redux-framework-master/redux-framework.php');
include_once('inc/redux-framework-master/sample/zsawyer-config.php');

