<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html <?php language_attributes();?>> <!--<![endif]-->
<head>

    <!-- Basic Page Needs
  ================================================== -->
	<meta charset="<?php bloginfo('charset');?>">
	<meta name="description" content="Free Responsive Html5 Css3 Templates | zerotheme.com">
	<meta name="author" content="www.zerotheme.com">
	
    <!-- Mobile Specific Metas
	================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
	<!--[if lt IE 8]>
       <div style=' clear: both; text-align:center; position: relative;'>
         <a href="http://windows.microsoft.com/en-US/internet-explorer/Items/ie/home?ocid=ie6_countdown_bannercode">
           <img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." />
        </a>
      </div>
    <![endif]-->
    <!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<script src="js/css3-mediaqueries.js"></script>
	<![endif]-->
<?php wp_head();?>	
</head>

<body>
	<div class="wrap-body">
		<div class="header">
			<div id='cssmenu' class="align-right">

				<?php wp_nav_menu(array(
				   	'theme_location'=>'main-menu',
	                'container'    => 'ul',
					'menu_class'      => 'has-sub',
				   	));
				?>

		</div>
	</div>
		<!--////////////////////////////////////Container-->
		<section id="container">
			<div class="wrap-container">
				<section class="content-box box-1">
					<div class="zerogrid">
						<div class="wrap-box"><!--Start Box-->
							<div class="row">
								<div class="">
									<div class="row">
										<div class="col-1-2">
											<a href="<?php echo site_url();?>"><img src="<?php global  $zsawyer_master; echo  $zsawyer_master['site_logo']['url']; ?>"></a>
										</div>
										<div class="col-1-2">
											<form id="form-container" action="" class="f-right">
												<!--<input type="submit" id="searchsubmit" value="" />-->
												<a class="search-submit-button" href="javascript:void(0)">
													<i class="fa fa-search"></i>
												</a>
												<div id="searchtext">
													<input type="text" id="s" name="s" placeholder="Search Something...">
												</div>
											</form>
										</div>
									</div>
								</div>
								<div id="owl-slide" class="owl-carousel">
									<?php 
										$zkimnet_post = null;
										$zkimnet_post = new WP_Query(array(
											'post_type'=>'slider',
											'posts_per_page'=>-1

										));
										if ($zkimnet_post->have_posts() ){
											while ($zkimnet_post->have_posts() ){
												$zkimnet_post->the_post(); ?>
												<li><?php the_post_thumbnail();?></li>
											<?php }
										}else{
											echo 'No Post';
										}
									?>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!--content-box-2-->
				<section class="content-box box-2">
					<div class="zerogrid">
						<div class="wrap-box"><!--Start Box-->
							<div class="row">
								
									<?php 
										$zkimnet_post = null;
										$zkimnet_post = new WP_Query(array(
											'post_type'=>'image',
											'posts_per_page'=>-1

										));
										if ($zkimnet_post->have_posts() ){
											while ($zkimnet_post->have_posts() ){
												$zkimnet_post->the_post(); ?>
											<div class="col-1-4">
												<div class="wrapper">
													<div class="portfolio-box">
														<?php the_post_thumbnail();?>
														<div class="portfolio-box-caption">
															<div class="portfolio-box-caption-content">
																<div class="project-category text-faded">
																	<?php the_title();?>
																</div>
																<div class="project-name">
																	<a href="single.html" style="color: #fff">Project Name</a>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<?php }
										}else{
											echo 'No Post';
										}
									?>	
								
							</div>
						</div>
					</div>
				</section>
				<!--content-box-3-->
				<section class="content-box boxstyle-1 box-3">
					<div class="zerogrid">
						<div class="row wrap-box"><!--Start Box-->
							<div class="header t-center">
								<div class="wrapper">
									<h2 class="color-yellow">FULL SERVICE CATERING, SERVICE STAFF, RENTALS, FLORAL DESIGN</h2>
									<span>Nulla ipsum dolor lacus, suscipit adipiscing. Cum sociis natoque penatibus et ultrices volutpat</span>
								</div>
							</div>	
							<div class="row">
								<?php 
										$zkimnet_post = null;
										$zkimnet_post = new WP_Query(array(
											'post_type'=>'services',
											'posts_per_page'=>-1

										));
										if ($zkimnet_post->have_posts() ){
											while ($zkimnet_post->have_posts() ){
												$zkimnet_post->the_post();
												$service_description = get_post_meta(get_the_ID(),'_zsawyer_service_description', true)
												?>
													<div class="col-1-4">
														<div class="wrap-col post">
															<div class="item-container">
																<div class="item-caption">
																	<div class="item-caption-inner">
																		<div class="item-caption-inner1">
																			<a class="example-image-link" href="<?php echo get_template_directory_uri();?>/images/portfolio-1.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
																				<i class="fa fa-search"></i>
																			</a>
																		</div>
																	</div>
																</div>
																<?php the_post_thumbnail();?>
															</div>
															<h3><?php the_title();?></h3>
															<p><?php echo $service_description; ?></p>
															<a class="button" href="#">Learn More</a>
														</div>
													</div>
											<?php }
										}else{
											echo 'No Post';
										}
									?>	
								
								<div class="col-1-4">
									<div class="wrap-col post">
										<div class="item-container">
											<div class="item-caption">
												<div class="item-caption-inner">
													<div class="item-caption-inner1">
														<a class="example-image-link" href="<?php echo get_template_directory_uri();?>/images/portfolio-2.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
															<i class="fa fa-search"></i>
														</a>
													</div>
												</div>
											</div>
											<img src="<?php echo get_template_directory_uri();?>/images/portfolio-2-thumb.jpg" alt=""/>
										</div>
										<h3>Banquet</h3>
										<p>His primis omittam ...</p>
										<a class="button" href="#">Learn More</a>
									</div>
								</div>
								<div class="col-1-4">
									<div class="wrap-col post">
										<div class="item-container">
											<div class="item-caption">
												<div class="item-caption-inner">
													<div class="item-caption-inner1">
														<a class="example-image-link" href="<?php echo get_template_directory_uri();?>/images/portfolio-3.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
															<i class="fa fa-search"></i>
														</a>
													</div>
												</div>
											</div>
											<img src="<?php echo get_template_directory_uri();?>/images/portfolio-3-thumb.jpg" alt=""/>
										</div>
										<h3>Banquet</h3>
										<p>His primis omittam ...</p>
										<a class="button" href="#">Learn More</a>
									</div>
								</div>
								<div class="col-1-4">
									<div class="wrap-col post">
										<div class="item-container">
											<div class="item-caption">
												<div class="item-caption-inner">
													<div class="item-caption-inner1">
														<a class="example-image-link" href="<?php echo get_template_directory_uri();?>/images/portfolio-4.jpg" data-lightbox="example-set" data-title="Click the right half of the image to move forward.">
															<i class="fa fa-search"></i>
														</a>
													</div>
												</div>
											</div>
											<img src="<?php echo get_template_directory_uri();?>/images/portfolio-4-thumb.jpg" alt=""/>
										</div>
										<h3>Banquet</h3>
										<p>His primis omittam ...</p>
										<a class="button" href="#">Learn More</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				
				<!--content-box-5-->
				<section class="content-box boxstyle-1 box-5">
					<div class="zerogrid">
						<div class="row wrap-box"><!--Start Box-->
							<div class="col-2-3">
								<div class="header">
									<div class="wrapper">
										<h2 class="color-yellow">LATEST FROM THE BLOG</h2>
									</div>
								</div>
								<?php 
										$the_query = null;
										$the_query = new WP_Query(array(
											'post_type'=>'post',
											'posts_per_page'=>3

										));
										if (have_posts() ){
											while ($the_query ->have_posts() ){
												$the_query ->the_post();?>
													<article>
														<div class="art-header">
															<a href="<?php the_permalink();?>"><h3><?php the_title();?></h3></a>
															<div class="info">Posted on <?php the_date();?> By: <?php the_author(); ?> <a href="<?php the_permalink();?>"><?php comments_number();?></a></div>
														</div>
														<div class="art-content">
															<?php the_post_thumbnail(); ?>
															<p><?php echo wp_trim_words(get_the_content(),50,'....');?></p>
														</div>
														<a class="button" href="<?php the_permalink();?>">Learn More</a>
														<div class="line"></div>
													</article>
												<?php }
										}else{
											echo 'No Post';
										}
									?>	
								
							</div>
							<div class="col-1-3">
								<div class="r-slidebar">
									<div class="wrap-col">
										<div class="post">
											<h5 class="color-red">LATEST COMMENTS</h5>
											<a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing eli...</a>
											<a href="#">Nastsea labore et dolore magames niausy aliquam quaerat voluptatem.</a>
											<a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing eli...</a>
											<a href="#">Lorem ipsum dolor sit amet, consectetuer adipiscing eli...</a>
										</div>
										<div class="post">
											<h5 class="color-blue">FEES & HOURS</h5>
											<p>Nastsea labore et dolore magames niausy aliquam quaerat voluptatem.</p>
										</div>
										<div class="post">
											<h5 class="color-yellow">ENROLLING YOUR CHILD</h5>
											<p>Nastsea labore et dolore magames niausy aliquam quaerat voluptatem.</p>
										</div>
										<div class="post">
											<h5 class="color-green">INFO FOR PARENTS</h5>
											<p>Nastsea labore et dolore magames niausy aliquam quaerat voluptatem.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				
			</div>
		</section>

<?php get_footer();?>
<?php wp_footer();?>
</body>
</html>